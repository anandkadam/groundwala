package com.example.demo.service;

import java.util.List;

import com.example.demo.model.TimeSlots;

public interface TimeSlotsService {
	
	public void addTimeSlots(TimeSlots t);
	public List<TimeSlots> getTimes() ;
		
		
	

}
